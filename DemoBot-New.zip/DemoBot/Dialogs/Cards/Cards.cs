using AdaptiveCards;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DemoBot.Dialogs
{
    public class Cards
    {
        public static Attachment getGreeting(string uname, string title, string subtitle)
        {
            string text = "Hello " + uname;
            string html = "<b><p>" + text + " </p></b>";

            List<CardImage> cardImages = new List<CardImage>();
            //cardImages.Add(new CardImage(url: "data:image/png; base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAN1wAADdcBQiibeAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAI9SURBVGiB7ZhNS9xQFIYfZRRsdeHW1qkWF9VNoaUzCGJLf9iIXVqVuigUdVfopuhK6U8oXersHIXSahcVi9jN + O3injBjzOe9NybRPBAynMx573tyP3ITKCjIHWVgBdiXYxUYSdWRBmXgH3DpOg6Axyn6is0KyvgaMAw8BdYl9jVFX7E5QpkebIs9kdhhEg12JiEKNOV80RZzfh8n1GYifKE1tAaAR7SG1ucUfcVmCNjj5mTfRQ2xXFEGlmkVscT1OZM7nEISJanJfuvc20JGgVmgDvxFLanuCe0 + HML + dyGam9LGqE5BYXQBC8BZBEO2jlPgA1CyVUQJ + CbiJ8AiUAH6gQ5bjYhWP1BFrXAn0uY6loqZE8E94KUNwYi8Av5I2zOmYmOoLm4Cz03FNHiB6plT4JmJ0Dzqjny0YEqXT + LhvYlIXUTGbTjSZEI8bJiI / BeRXhuONOkTD0cmImHbiwfAFNBAvRFuATWgx3KO8TYnSOAh8APvZ8B3MWwjJ8xHJIIE3sm1bWAS9Qx4DexIvGYpJ8xHJIIEnMbfuOJvJd6wlBPmw / fPQfuldo7xXgicydm8kaGXE8mbye73l5wrrnhVzj8t5cTG6 + 4H9ci0XPuNGu / dqPG + i / 9418mJ7S1uIWmvWtYKgevPhHPiP0ei5iReyG0R6u3evupmlqKQrOH1LpyFye2HrzfTl3rbRWt / zGgvxEska73jW6itb0buBi4149rcmcleFJI1ikKyRti6nZvl9870SEFBQlwBjAsRgpoX4JgAAAAASUVORK5CYII="));
            cardImages.Add(new CardImage(url: "data: image / jpg; base64,/ 9j / 4AAQSkZJRgABAgAAZABkAAD / 7AARRHVja3kAAQAEAAAAZAAA / +EDKmh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDozNkE4MUNFMkM3QTcxMUU4ODdCRDhENEEwQTRENjU1NCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDozNkE4MUNFMUM3QTcxMUU4ODdCRDhENEEwQTRENjU1NCIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QUVFMzBFNTI1OUJBMTFFOEFDM0FFMEUxREI3ODAwRTEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QUVFMzBFNTM1OUJBMTFFOEFDM0FFMEUxREI3ODAwRTEiLz4gPC9yZGY6RGVzY3JpcHRpb24 + IDwvcmRmOlJERj4gPC94OnhtcG1ldGE + IDw / eHBhY2tldCBlbmQ9InIiPz7 / 7gAOQWRvYmUAZMAAAAAB / 9sAhAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAgICAgICAgICAgIDAwMDAwMDAwMDAQEBAQEBAQIBAQICAgECAgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwP / wAARCABRAFYDAREAAhEBAxEB / 8QAewABAAMBAQEBAQAAAAAAAAAAAAgJCgcGBAILAQEAAAAAAAAAAAAAAAAAAAAAEAAABgICAQEEBAoLAQAAAAABAgMEBQYHCAAJERIhExQKIhXXGTFBURbWl1iYWRphgTJCYiMlF3e3eDkRAQAAAAAAAAAAAAAAAAAAAAD / 2gAMAwEAAhEDEQA / AN / HAcBwHAcDiclstrlD3guMZfP + E4rJRnJGRceyWVaKxvBniogCbQtTczyU + LlQRD0p / D + sfPsDgds4DgOA4DgOA4DgOBSh3O5 / zxWYTUPS7WO9r4ezJ2J7EIYBJnBkmVaZw / i6Fr7i25bt9TTMJfTdgrCQN4xQDFOiosc6Zk1QTVTDxcV8tf1FoY6PTrNrrJ327vm5lpvYG3ZOyM + z5M2lUxV3N4Xv6FlbKNbMpIB8QU6DdNBNT8CXgPHA + XqRyRnDCuye7XVFnXKFlz230wTxPkLXXNt4d / WWQ7DrlmqIfPatS8ky5jGWnLXjp9HGZA / U / wAx22OURH0kKUoX28BwHAcBwHAcBwKsu1nRvJe4eKcT3bW + 6QmONw9Q8wwGxmrlutCa6tPd3muoLM5jH14I3KosWm5GgVjsHqhU1BSN7oximTBQohUJLfM82HHGWWekeXetbYCN7JFZmvY + Q18qd7xjKY9tGSLOxZrV01cya4nvUjUbOL5F01XOzce5ZrB61TiUx + BaJ1baVZ + w / admd1d2ZOqPd1t3bNWJzIdTobtSSouDcYUGNcRWLMG1aYVOf6 +/ NKNeqmkH5BFJ07P9AygEFZULhOA4DgOA4HH9g81VTW / BWYtgL0Dg1PwvjS6ZOsaLMAF67iaVX39gdMGIGASi / kCMfcIAPsFVQvn2cDOxrvpt2H9qGJKjuvtJ2SbM6fxOfYtrknCWrGl0nW6HVcR4jsqf1hQ2V2tU / ATcxervLVtZu7erqESBE6wE8 + QMQgdt + 4dyl / Gs7av11UX7PeA + 4dyl / Gs7av11UX7PeBGCc + VCwXZ83M9l7F2G9gM3sRHzEPYWGbZK7Y1cZIZTteQbtYGWa2Q2PPikXsQ2aJJtzB49BEwDgSf + 4dyl / Gs7av11UX7PeA + 4dyl + Pur7avH / ADXRfs94HnMbXHczqk3b1d1a2I2gu28Wl + 81knsVYZyvmSPhEdgcCZ8hIEJ2Ep1tssKkxa36jX1i2Ok1XURK4bOvPpIkRIwOA0e8BwHAzl / MDdjmKMQat7KaO06l5Bz5s5mTVfKk7M48xPFFlksI4cWr8iwmM45qnDCZlTKTFek5kEzAo8fnJ4ImRMffAFqnWaAB12aMAA + oA1L1 / ADB / eAMX1n2 / wBfAjl2bbs5418vem + rerMPiprsLvHk + 40Gl5Qz4tMpYYxXC46p57rbJqcYQKzKUtVsko / 0t4SIRcIi8diJTCPkoCH09Y + 6uc9irRt / rdtDD4rX2D0gy3W8Y3rJWBHMw4wvlONu9RRulVn640nVXcpWbMyjVDN5yHXXVMxeABQEAESgFsnAzmbMdjm / Fo2S3vx7palqDj / HHWRTqjas0JbTvraFzz1M2PH5souoemDXJeLZY5obOsomZozzwq5V5Q4B7E / UCYXLaW7KR + 4upuvW0kXWJKlss74pqOSE6pLHBZ7AK2KMSdOowXIJpA + bNnYnBu4AhAct / Qr6S + vwAUj / ADDd8u2Lr3095FxxiiezreaT2OVmzVnDtXlWUJZMjScTj20OkqtBSski4YM5aRIQxUDKkMQVPACHt4FuOhfYFgzsJxVK5CxKS01K10axu6FmjCWTIcatl7CGSYopfrej5Dqyiyx2L5ucRFByidVo7TD1Jn9RVCECcnAcDDhc1meKsgfNVYoz8BYbaTNOKMh5uwQ8tKyRJfIWm6NPvLaqNcdP3qhTv6 / TDuG6L9i0MPu1SlE6Y + 4EShqu6zP / AJ1aLf8AkrX7 / q6scDo + 12nOt27uMi4j2dxdDZPpbWaY2aGReuZOHnataIwFCx1mp9rr76Ks1TsDMixykdx7tut6DmKJhKIhwPL6u6 + 6d6OQ8VqnrdXaHih1Ms5 / KYY9az55HId2SI / j4qz5KsLuwSkldro4LIu2rZ3KvVnJiHOkkKgfRLwJhcCrzYDrW6yOwrKz3LeXsRY8zJk7GckGLb7OVm5z8S7eOKudrLFxhmVjQ7LENLi1gvj0lQiJ9J0CBFih6AIYA4FlsDAwlWhIes1qIjYCu1 + MYwsFBw7JvHRMNDxbZJlGxcZHtE0mrFgwZokSRSTKUiaZQKUAAA4FDPdIUTbQdGAFATD96VQjeAARHwWi2Yxh8B + IpQER / IAcDhuiT2Ay38xP2Z5211RJL64V / V3G + C8yZAqnj / bm27ewVkx3JO2TZ60AsVP26q0uNfs37lEVDJqAoBjj70DHDTdwHAo579tEte9r + v3Y3KOQ8Up2jNeueAMvX3CWQq8vIwuQanIRFTkZqQimkzCKoPpepSyTEwyEM7BwwdJgYRSBTwcAml1ZzsRZetnRCagpJjLxbzU3A4IP45dNy0UVa44r7N4kVVIxigq0et1EVSf2k1UzEMAGKIAE9OBWhvFp9mXJOVMEbi6gXShUTb / WxhdalBsssR0u / wAR5swxkgIta + 4UyUtXANZq + zeysCxk4iYjyqrxco1KcySqShwAONOsrd7cw2Wh4vUDr2pMm / TMya3Wb2uy1cYSvOFQ90E48qEVhCAlp5qzMPvQZJvmqivj0CqXz6uBLbQPTkmluEZOlTt5c5YzBlHJN5zzsPl11Fowhsl5xyjJFl7rYI + DbnVSga0zFJCPiGAHP8JGskSCYT + oRCb3AzS / MHYmqOyOXem / WS0TNmYNsv7 / AKbWaaUCzvKnkEKFE43nPz4m65NxZglockNHSCfxD1DwZuRYB9RREB4F7GsGq + AdM8OVnAmtWNYHFmLqoVY7Cvwaayiz6TeCU8nYbDLvlXUvZLLMLEBR3IPV13Tg / j1HEAKABILgOB8cjHMJePfRMqyaSUXKM3UdJRz9uk7Yv2D1A7Z4yeNVynQctHTdUyaiZyiQ5DCAgIDwMT3ZNq7219Klas + U + mfLF6sGh8vJTVuuWr8hTqpml / q7OSj1zLzchjGBt9dn5ouHZRdY6wpMPUrELev4kqiRyrlDNWf5qzu3TOdNTZanJqJnMRRM + vuEiHTOQRKchyGo4GIcpg8CA + 0B4H5 / mr + 7T9pimfu / 4R / QfgP5q / u0 / aYpn7v + Ef0H4D + av7tP2mKZ + 7 / hH9B + B1jCXzHXzDGyOR6 / iPAuTC5ayVaHSbSDp1I1kw7OS7s5zkIK6qTWiGSYR6AnAVnTgyTZAn0lDlKAjwNwPWJ1kbCVLIEF2BdpWZZLZLsOkqU9qtVYqOIgMV6rUmwgZWXpOK69XWEbWELXLJLnTmZVkgRE / vFEG / rIZRw4C + rgOA4DgUbd9nach1nafPzY4VJN7a7BGkcZa1UtigaVmkp562I3nckjBtk3Dp7G0Bk + IqiT3ZiOpZdm3EDFUP4D + fBpp8tz2v72Sba7SuJFcAUS1vjTUnlTZNZ9SnMgWWcHdvZhjRwZvL / NOF1ljqD / AKeimcwj5ULwL + JT5HxmaqwYwvYI7Su5Y0g2QkpgdFeqqzA + BULBqNcit5dvGk8 + kplyqKm8eoQL59AB4KG + R + yKeQIWw9gFMbRXvPpqw2Dpt7ICl / gQfXyPbFUEPyqCAf08Cw3APyXWhFDkGcrnzPefM / C390ovXosa9iOrvFCCBjpOiwiVhtBmpxDwIIyjc4l / AYB9vA01an6IagaN1I1L1T1 / x1hmJcETLKvaxCJmtFiUSIVMriz3GSM + tVkc + kgfTevFxDwAB4AADgS24DgOA4DgcZf68YQl8yNdg5nGFRms0x9TQo0Tkabi05ixwNUQkHEqENXHEmLpGuN15B0dVczEjdVybx70xwKUADs3AcBwHAcBwHAcBwHAcBwHAcBwHAcBwHA//9k="));

            var greetingCard = new ThumbnailCard
            {
                Title = title,
                Subtitle = subtitle,
                Images = cardImages
            };

            return greetingCard.ToAttachment();
        }

        public Attachment AdaptiveCardMessage(string promptMessage, string speakMessage)
        {
            AdaptiveCard adaptiveCard = new AdaptiveCard()
            {
                Body = new List<AdaptiveElement>()
                {
                    new AdaptiveTextBlock()
                    {

                       Text = promptMessage,
                       Wrap = true,
                    }
                },
                Actions = new List<AdaptiveAction>()
                {
                    new AdaptiveSubmitAction()
                    {
                        Title = "Yes",
                        Data = "Yes"
                    },
                     new AdaptiveSubmitAction()
                    {
                        Title = "No",
                        Data = "No"
                    }
                }
            };

            // string speak = messageActivity.Speak + "." + WSS.ChatBot.Common.Common.HeaderMessage;
            adaptiveCard.Speak = speakMessage;


            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = adaptiveCard
            };
            return attachment;
        }

        public async Task YesNoCard(IDialogContext context, string botResponse2Message)
        {
            List<CardAction> cardButtons = new List<CardAction>();
            List<CardAction> yesno = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: "Yes", value: "Yes"),
                new CardAction(ActionTypes.ImBack, "No", value: "No") };
            HeroCard card = new HeroCard { Text = botResponse2Message, Buttons = yesno };
            var makeMessage = context.MakeMessage();
            makeMessage.Attachments.Add(card.ToAttachment());
            await context.PostAsync(makeMessage);

        }
     
    }
}
