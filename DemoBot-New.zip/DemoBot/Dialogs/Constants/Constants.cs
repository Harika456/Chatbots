using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoBot.Dialogs
{
    public class Constants
    {
      public const string YesNoPrompt = "\n\n Was I able to resolve your query?";
    public const string CommonMessage = "Please choose one of the below options:";

    public const string IncompatibleFuel = "Incompatible fuels";
    public const string HighWater = "High water content";
    public const string Both = "Unstable asphaltenes";
    public const string None = "Any other reason";


    public static List<string> HeavySludgeModelCollection()
    {
      List<string> listHeavySludgeModel = new List<string>();
      listHeavySludgeModel.Add(IncompatibleFuel);
      listHeavySludgeModel.Add(HighWater);
      listHeavySludgeModel.Add(Both);
      listHeavySludgeModel.Add(None);
      return listHeavySludgeModel;
    }

    public const string Ropes1 = "Conventional mooring ropes";
      public const string Ropes2 = "Advanced mooring ropes";
      public const string Ropes3 = "High performance ropes";
      public const string Ropes4 = "Mooring stretchers";
      public static List<string> RopesModelCollection()
      {
        List<string> listRopes = new List<string>();
        listRopes.Add(Ropes1);
        listRopes.Add(Ropes2);
        listRopes.Add(Ropes3);
        listRopes.Add(Ropes4);
        return listRopes;
      }
    public const string Ropes3_Option1 = "What are the Acera ropes made of?";
    public const string Ropes3_Option2 = "What is the cover of Acera daGama made of?";
    public const string Ropes3_Option3 = "Do you offer HMPE ropes with bigger diameter?";
    public const string Ropes3_Option4 = "Can we use Acera ropes in terminals with HMPE?";

    public static List<string> Ropes3ModelCollection()
    {
      List<string> listRopes_3 = new List<string>();
      listRopes_3.Add(Ropes3_Option1);
      listRopes_3.Add(Ropes3_Option2);
      listRopes_3.Add(Ropes3_Option3);
      listRopes_3.Add(Ropes3_Option4);
      return listRopes_3;
    }

    public const string Ropes3_Option1_1 = "Where do you produce the Acera HMPE ropes?";
    public const string Ropes3_Option1_2 = "What certification do you have for your Acera HMPE ropes?";
    public static List<string> Ropes3_Option1ModelCollection()
    {
      List<string> listRopes_3_Option1 = new List<string>();
      listRopes_3_Option1.Add(Ropes3_Option1_1);
      listRopes_3_Option1.Add(Ropes3_Option1_2);
      return listRopes_3_Option1;
    }
  }
}
