using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DemoBot.Dialogs
{
    [Serializable]
    public class HeavySludge : IDialog<object>
    {      
        public async Task Main(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {       

            var MessageActivity = await activity;
            PromptDialog.Choice(context, this.AfterMenuSelection,
            Constants.HeavySludgeModelCollection(), "Choose from below options:", "Please choose a valid option from below !!", 1);

        }

        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string Prompt = string.Empty;
            
            Cards cards = new Cards();
            switch (message.ToString())
            {
                case Constants.IncompatibleFuel:
                case "1":
                    Prompt = $"You should stabilize fuel with FuelPower Conditioner. Please [click here](https://wilhelmsen.com/product-catalogue/products/marine-chemicals/fuel-oil-chemicals/heavy-fuel-oil-treatment/fuel-power-conditioner-25-ltr/?epieditmode=true) for the product details and dosage details";
                    break;
                case Constants.HighWater:
                case "2":
                    Prompt = $"Please demulsify water in fuel with FuelPower Demulsifier. Please [click here](https://wilhelmsen.com/product-catalogue/products/marine-chemicals/fuel-oil-chemicals/heavy-fuel-oil-treatment/fuel-power-demulsifier-25-ltr/?epieditmode=true) for the product details and dosage details.";
                    break;
                case Constants.Both:
                case "3":
                    Prompt = "You should stabilize fuel with FuelPower Conditioner. Please [click here](https://wilhelmsen.com/product-catalogue/products/marine-chemicals/fuel-oil-chemicals/heavy-fuel-oil-treatment/fuel-power-conditioner-25-ltr/?epieditmode=true) for the product details and dosage details.";
                    break;
                case Constants.None:
                case "4":
                  Prompt = "We will send your request to our customer service and will get in touch with you soon.";
          break;
        default:
                    break;
            }
            await cards.YesNoCard(context, Prompt + Constants.YesNoPrompt);           

        }

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}
