using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.FormFlow;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using System.Globalization;
using AdaptiveCards;

namespace DemoBot.Dialogs
{
    [Serializable]
    [LuisModel("1cbc3953-9696-4a20-9e1f-4766908ab387", "cf27c9e49ed4416884fe4710c8c7df62", LuisApiVersion.V2, "southeastasia.api.cognitive.microsoft.com", Log = true, SpellCheck = true)]  
    public class RootDialog : LuisDialog<object>
    {
        [LuisIntent("None")]
        [LuisIntent("Unknown_Intent")] 
        public async Task None(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var Message = await activity;
            string message = $"Hey I am still learning and working on your query  **{result.Query}**. \n\n Right now I can help you with \n\n **Window cleaning products** \n\n **Oven cleaning products** \n\n **Sludge removal products** and \n\n **Ropes products**. ";
            await context.PostAsync(message);
            context.Wait(this.MessageReceived);
        }

       
        [LuisIntent("Yes")]
        public async Task Yes(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var Message = await activity;
            string message = $"Thank you for your time and have a nice day.";
            await context.PostAsync(message);
            context.Wait(this.MessageReceived);
        }
    
        [LuisIntent("No")]
        public async Task No(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
          var Message = await activity;
          string message = $"We will forward your request to our support team. \n\n Thank you for your time and have a nice day.";
          await context.PostAsync(message);
          context.Wait(this.MessageReceived);
        }


        [LuisIntent("Greetings")]
        public async Task Greetings(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
      var makeMessage = context.MakeMessage();
      string title = $"Hi {context.Activity.From.Name} !! I am IBot.";
      string subtitle = " and I can help resolve your queries . \n Go ahead and talk to me.";

      var attachment = Cards.getGreeting(context.Activity.From.Name, title, subtitle);

      makeMessage.Attachments.Add(attachment);
      makeMessage.Speak = title + subtitle;
      makeMessage.InputHint = InputHints.AcceptingInput;
      await context.PostAsync(makeMessage);
    }

        [LuisIntent("EasyClean_Window_And_Mirror")]
        public async Task Laptops(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            string replyMsg = "1.Spray **EasyClean Window & Mirror** on the surface at a concentration of 0.5 % to 1 %, wipe dry with a squeegee, dry cloth or paper towel. \n\n" +
                 "2. [Click here](https://wilhelmsen.com/product-catalogue/products/marine-chemicals/cleaning-chemicals/galley-and-accommodation/easyclean-window--mirror/?epieditmode=true) for more product info. \n\n Was I able to help resolve your query?";
            Cards cards = new Cards();
            var makeMessage = context.MakeMessage();
            var attachment = cards.AdaptiveCardMessage(replyMsg, replyMsg);
            makeMessage.Attachments.Add(attachment);
            await context.PostAsync(makeMessage);
            context.Done<object>(null);
        }

        [LuisIntent("Easyclean_Oven_And_Grill")]
        public async Task Refrigerators(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            string replyMsg = "1. Spray **EasyClean Oven & Grill** undiluted on cold surfaces, leave for 15 - 60 minutes and rinse properly with water. \n\n" +
               "2. [Click here](https://wilhelmsen.com/product-catalogue/products/marine-chemicals/cleaning-chemicals/galley-and-accommodation/easyclean-oven--grill/?epieditmode=true) for more product info.\n\n Was I able to help resolve your query?";
            Cards cards = new Cards();
            var makeMessage = context.MakeMessage();
            var attachment = cards.AdaptiveCardMessage(replyMsg, replyMsg);
            makeMessage.Attachments.Add(attachment);
            await context.PostAsync(makeMessage);
            //await cards.YesNoCard(context, replyMsg + Constants.YesNoPrompt);
        }

        [LuisIntent("Ropes")]
        public async Task Mobiles(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            Ropes ropes = new Ropes();
            await ropes.Main(context, activity);
        }

        [LuisIntent("HeavySludge")]
        public async Task HomeAppliances(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            HeavySludge heavySludge = new HeavySludge();
            await heavySludge.Main(context, activity);
        }  
        
        private AdaptiveCard Card(string promptMessage)
        {
            
            AdaptiveCard adaptiveCard = new AdaptiveCard()
            {
                Body = new List<AdaptiveElement>()
                {
                    new AdaptiveTextBlock()
                    {
                         Text = promptMessage
                    }
                },
                Actions = new List<AdaptiveAction>()
                {
                    new AdaptiveSubmitAction()
                    {
                         Title = "option1",
                         Data = "option 1 answer"
                    }
                }
            };

            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                 Content = adaptiveCard
            };

            return adaptiveCard;
        }

    }
}
