﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.FormFlow;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using System.Globalization;
using AdaptiveCards;

namespace DemoBot.Dialogs
{
    [Serializable]
    [LuisModel("1cbc3953-9696-4a20-9e1f-4766908ab387", "cf27c9e49ed4416884fe4710c8c7df62", LuisApiVersion.V2, "southeastasia.api.cognitive.microsoft.com", Log = true, SpellCheck = true)]  
    public class RootDialog : LuisDialog<object>
    {
        [LuisIntent("None")]
        public async Task None(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var Message = await activity;
            string message = $"Hey I am still learning and working on your query  **{result.Query}**. \n\n Right now I can help you with \n\n **Laptops** \n\n **Refrigerators** \n\n **Smart Phones** and \n\n **Home Appliances**. ";
            await context.PostAsync(message);
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("Yes")]
        public async Task Yes(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var Message = await activity;
            string message = $"Thank you for your time and have a nice day.";
            await context.PostAsync(message);
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("No")]
        public async Task No(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var Message = await activity;
            string message = $"Thank you for your time and have a nice day.";
            await context.PostAsync(message);
            context.Wait(this.MessageReceived);
        }


        [LuisIntent("Greetings")]
        public async Task Greetings(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            var makeMessage = context.MakeMessage();
            string title = $"Hi {context.Activity.From.Name} !! Welcome to Amazon services.";
            string subtitle = " I can help you finding the following products: \n\nLaptops \n\nRefrigerators \n\nSmart Phones \n\nHome Appliances";

            var attachment = Cards.getGreeting(context.Activity.From.Name, title, subtitle);

            makeMessage.Attachments.Add(attachment);

            await context.PostAsync(makeMessage);
        }

        [LuisIntent("Laptops")]
        public async Task Laptops(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            string replyMsg = @"We have **HP 2018 Elitebook 840 G1 14"" HD LED-backlit anti - glare Laptop** . Please  [click here](https://www.amazon.com/Elitebook-840-LED-backlit-Professional-Refurbished/dp/B07CSQDR4N/ref=sr_1_1_sspa?ie=UTF8&qid=1540891115&sr=8-1-spons&keywords=hp+laptop&psc=1) " +
                              @"to view them.";
            Cards cards = new Cards();
            await cards.YesNoCard(context, replyMsg + Constants.YesNoPrompt);
          
        }

        [LuisIntent("Refrigerators")]
        public async Task Refrigerators(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            string replyMsg = @"We have **Kenmore Smart 75043 24 cu. ft. French Door Bottom-Mount Refrigerator in Stainless Steel** . Please  [click here](https://www.amazon.com/Kenmore-Smart-75043-Bottom-Mount-Refrigerator/dp/B0745QQHF9/ref=sr_1_1_sspa?ie=UTF8&qid=1540891096&sr=8-1-spons&keywords=lg+refrigerators&psc=1) " +
                    @"to view them.";
            Cards cards = new Cards();
            await cards.YesNoCard(context, replyMsg + Constants.YesNoPrompt);
        }

        [LuisIntent("Mobiles")]
        public async Task Mobiles(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            SmartPhones mobiles = new SmartPhones();
            await mobiles.Main(context, activity);
        }

        [LuisIntent("HomeAppliances")]
        public async Task HomeAppliances(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
        {
            HomeAppliances homeAppliances = new HomeAppliances();
            await homeAppliances.Main(context, activity);
        }    

    }
}