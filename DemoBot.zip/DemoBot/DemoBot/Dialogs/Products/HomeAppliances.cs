﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DemoBot.Dialogs
{
    [Serializable]
    public class HomeAppliances : IDialog<object>
    {      
        public async Task Main(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {       

            var MessageActivity = await activity;
            PromptDialog.Choice(context, this.AfterMenuSelection,
            Constants.HomeAppliancesOptions(), "Choose from below options:", "Please choose a valid option from below !!", 1);

        }

        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string Prompt = string.Empty;
            
            Cards cards = new Cards();
            switch (message.ToString())
            {
                case Constants.Electrical:
                case "1":
                    Prompt = $"We have many electrical appliances. Please [click here](https://www.amazon.com/s/ref=s9_acss_bw_cts_AEVNTOOL_T2_w?fst=as%3Aoff&rh=n%3A228013%2Cn%3A!468248%2Cn%3A256643011%2Cn%3A495266&bbn=256643011&ie=UTF8&qid=1490122794&rnid=468240&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=merchandised-search-3&pf_rd_r=DY6YY87T680NK8CX03B9&pf_rd_t=101&pf_rd_p=699f0b2b-c69c-4589-9550-bf4cf2ec220f&pf_rd_i=256643011) " +
                    $"to view them.";
                    break;
                case Constants.Hardware:
                case "2":
                    Prompt = $"We have many hardware appliances. Please  [click here](https://www.amazon.com/s/ref=s9_acss_bw_cts_AEVNTOOL_T3_w?fst=as%3Aoff&rh=n%3A228013%2Cn%3A!468248%2Cn%3A256643011%2Cn%3A511228&bbn=256643011&ie=UTF8&qid=1490122794&rnid=468240&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=merchandised-search-3&pf_rd_r=DY6YY87T680NK8CX03B9&pf_rd_t=101&pf_rd_p=699f0b2b-c69c-4589-9550-bf4cf2ec220f&pf_rd_i=256643011) " +
                    $"to view them.";
                    break;
                case Constants.LightsAndBulbs:
                case "3":
                    Prompt = $"We have many lights and bulb appliances. Please  [click here](https://www.amazon.com/s/ref=s9_acss_bw_cts_AEVNTOOL_T1_w?fst=as%3Aoff&rh=n%3A228013%2Cn%3A!468248%2Cn%3A256643011%2Cn%3A322525011&bbn=256643011&ie=UTF8&qid=1490122794&rnid=468240&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=merchandised-search-4&pf_rd_r=DY6YY87T680NK8CX03B9&pf_rd_t=101&pf_rd_p=1f2928c3-5b4a-427f-9a75-1695e30dfc52&pf_rd_i=256643011) " +
                    $"to view them.";
                    break;
                default:
                    break;
            }
            await cards.YesNoCard(context, Prompt + Constants.YesNoPrompt);           

        }

        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }

    }
}