﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DemoBot.Dialogs
{
    [Serializable]
    public class SmartPhones : IDialog<object>
    {
       
        public async Task Main(IDialogContext context, IAwaitable<IMessageActivity> activity)
        {
            var messageActivity = await activity;          
            string replyMsg = string.Empty;
            
                PromptDialog.Choice(context, this.Level1,
                 Constants.MobilesOptions(), "Choose from below options: ", "Please choose a valid option from below !!", 1);
           
        }
        private async Task Level1(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            string prompt;
           
            switch (message.ToString())
            {
               
                case Constants.Android:
                case "1": 
                        PromptDialog.Choice(context, this.Android, Constants.AndroidOptions(), "Choose from below options:", "Please choose a valid option from below !!", 1);
                break;

                case Constants.Iphone:
                case "2":                     
                        PromptDialog.Choice(context, this.IphoneOptions, Constants.IPhoneOptions(), "Choose from below options:", "Please choose a valid option from below !!", 1);
                break;
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";                   
                    PromptDialog.Text(context, this.Level1, prompt);
                    return;

            }

        }

        private async Task Android(IDialogContext context, IAwaitable<string> result)
        {
            var prompt = string.Empty;
            var options = await result;
            
            switch (options)
            {
               
                case Constants.Samsung:
                case "1":                  

                        PromptDialog.Choice(context, this.SamsungOptions,
                        Constants.SamsungOptions(), "Choose from below options:", "Please choose a valid option from below !!", 1);
                       
                   
                    break;

                case Constants.RedMi:
                case "no":
                case "2":
                    PromptDialog.Choice(context, this.RedMiOptions,
                         Constants.RedMiOptions(), "Choose from below options:", "Please choose a valid option from below !!", 1);

                    break;


                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";
                   
                    PromptDialog.Text(context, this.Android, prompt);
                    return;
            }


        }

        private async Task SamsungOptions(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            Cards cards = new Cards();
            string prompt = string.Empty;
            string prompt2 = string.Empty;
            switch (message.ToString())
            {
                case Constants.SamsungJ7:
                case "1":                    
                    prompt = @"We have **Samsung Galaxy J7 Neo (16GB) J701M/DS - 5.5"", Android 7.0, Dual SIM Unlocked Smartphone, International Model(Silver)**. Please  [click here](https://www.amazon.com/Samsung-Galaxy-16GB-J701M-DS/dp/B074FS1FW9/ref=sr_1_4?ie=UTF8&qid=1540892206&sr=8-4&keywords=smart+phones) " +
                   @"to view the product.";
                    await cards.YesNoCard(context, prompt + Constants.YesNoPrompt);
                    break;

                case Constants.SamsungS8:
                case "2":
                    prompt = @"We have **Samsung Galaxy S8 Unlocked 64GB - US Version (Midnight Black) - US Warranty**. Please  [click here](https://www.amazon.com/Samsung-Galaxy-S8-Unlocked-64GB/dp/B06Y14T5YW/ref=sr_1_5?ie=UTF8&qid=1540892413&sr=8-5&keywords=smart+phones) " +
                    @"to view the product.";
                    await cards.YesNoCard(context, prompt + Constants.YesNoPrompt);
                    break;
               
                default:
                    prompt = "You have selected an invalid option. Please select valid option.";                    
                    PromptDialog.Text(context, this.SamsungOptions, prompt);
                    return;
            }
        }

        private async Task RedMiOptions(IDialogContext context, IAwaitable<object> result)
        {
            var message = await result;
            Cards cards = new Cards();
            string prompt = string.Empty;
            string prompt2 = string.Empty;
            switch (message.ToString())
            {
                case Constants.RedMiNote3:
                case "1":
                    prompt = @"We have **Xiaomi Redmi Note3 Unlocked Cell Phone, 32GbFeatures, LTE Factory**. Please  [click here](https://www.amazon.com/Xiaomi-Redmi-Unlocked-32GbFeatures-Factory/dp/B00PLE2ROM/ref=sr_1_2?ie=UTF8&qid=1540892300&sr=8-2&keywords=mi+note+5+pro) " +
                   @"to view the product."; await cards.YesNoCard(context, prompt + Constants.YesNoPrompt);
                    break;

                case Constants.RedMiNote5:
                case "2":
                    prompt = @"We have **Xiaomi Redmi Note 5 32GB ROM + 3GB RAM, Dual Camera, Unlocked Smartphone - International Version**. Please  [click here](https://www.amazon.com/Xiaomi-Redmi-Camera-Unlocked-Smartphone/dp/B07CZS8W5Y/ref=sr_1_1?ie=UTF8&qid=1540892486&sr=8-1&keywords=mi+note+5+pro) " +
                    @"to view the product."; await cards.YesNoCard(context, prompt + Constants.YesNoPrompt);
                    break;

                default:
                    prompt = "You have selected an invalid option. Please select valid option.";
                    PromptDialog.Text(context, this.SamsungOptions, prompt);
                    return;
            }
        }

        private async Task IphoneOptions(IDialogContext context, IAwaitable<object> result)
        {
            string prompt = string.Empty;
            var Options = await result;
            Cards cards = new Cards();
            switch (Options.ToString())
            {
                case Constants.IphoneX:
                case "1":
                    
                        prompt = @"We have **Apple iPhone X, Fully Unlocked 5.8"", 64 GB - Silver **. Please  [click here](https://www.amazon.com/Apple-iPhone-Fully-Unlocked-5-8/dp/B075QN8NDH/ref=sr_1_1?s=wireless&ie=UTF8&qid=1540892510&sr=1-1&keywords=iphone) " +
                   @"to view the product.";
                    await cards.YesNoCard(context, prompt + Constants.YesNoPrompt);
                    break;

                case Constants.IphonXSMax:
                case "no":
                case "2":
                    prompt = @"We have **Apple iPhone XS Max 6.5"" Smartphone Unlocked 64GB 4G LTE Space Gray**. Please  [click here](https://www.amazon.com/Apple-iPhone-Smartphone-Unlocked-Space/dp/B07HKVTDZV/ref=sr_1_2?s=wireless&ie=UTF8&qid=1540892510&sr=1-2&keywords=iphone) " +
                    @"to view the product.";
                    await cards.YesNoCard(context, prompt + Constants.YesNoPrompt);
                    break;
                default:
                    prompt = "It seems like you have selected an invalid option. Can you please enter your option again.";                   
                    PromptDialog.Text(context, this.IphoneOptions, prompt);
                    return;
            }           
        }   


        public Task StartAsync(IDialogContext context)
        {
            throw new NotImplementedException();
        }
    }
}