﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoBot.Dialogs
{
    public class Constants
    {
        public const string Electrical = "Electrical";
        public const string Hardware = "Hardware";
        public const string LightsAndBulbs = "Lights and Bulbs";
        public const string YesNoPrompt = "\n\n Was I able to resolve your query?";
        public static List<string> HomeAppliancesOptions()
        {
            List<string> HomeAppliances = new List<string>();
            HomeAppliances.Add(Electrical);
            HomeAppliances.Add(Hardware);
            HomeAppliances.Add(LightsAndBulbs);
            return HomeAppliances;
        }        

        public const string Android = "Android Phones";
        public const string Iphone = "I Phones";       
        public static List<string> MobilesOptions()
        {
            List<string> Mobiles = new List<string>();
            Mobiles.Add(Android);
            Mobiles.Add(Iphone);
            return Mobiles;
        }

        public const string Samsung = "Samsung";
        public const string RedMi = "RedMi";        
        public static List<string> AndroidOptions()
        {
            List<string> Android = new List<string>();
            Android.Add(Samsung);
            Android.Add(RedMi);
            return Android;
        }


        public const string SamsungJ7 = "Samsung J7";
        public const string SamsungS8 = "Samsung S8";
        public static List<string> SamsungOptions()
        {
            List<string> Samsung = new List<string>();
            Samsung.Add(SamsungJ7);
            Samsung.Add(SamsungS8);
            return Samsung;
        }

        public const string RedMiNote3 = "Red Mi Note3";
        public const string RedMiNote5 = "Red Mi Note5";
        public static List<string>RedMiOptions()
        {
            List<string> RedMi = new List<string>();
            RedMi.Add(RedMiNote3);
            RedMi.Add(RedMiNote5);
            return RedMi;
        }

        public const string IphoneX = "IPhone X";
        public const string IphonXSMax = "IPhone XS Max";
        public static List<string> IPhoneOptions()
        {
            List<string> IPhone = new List<string>();
            IPhone.Add(IphoneX);
            IPhone.Add(IphonXSMax);
            return IPhone;
        }

        public const string Laptops = "Laptops";
        public const string Refrigerators = "Refrigerators";
        public const string SmartPhones = "Smart Phones";
        public const string HomeAppliances = "Home Appliances";
        public static List<string> MainOptions()
        {
            List<string> MainOptions = new List<string>();
            MainOptions.Add(Laptops);
            MainOptions.Add(Refrigerators);
            MainOptions.Add(SmartPhones);
            MainOptions.Add(HomeAppliances);
            return MainOptions;
        }

    }
}